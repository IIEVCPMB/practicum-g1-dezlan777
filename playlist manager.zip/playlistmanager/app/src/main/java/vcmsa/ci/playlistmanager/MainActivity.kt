package vcmsa.ci.playlistmanager

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.playlistmanager.DetailActivity

class MainActivity : AppCompatActivity() {

    // Parallel arrays to store data
    private val titles = arrayListOf<String>()
    private val artists = arrayListOf<String>()
    private val ratings = arrayListOf<Int>()
    private val comments = arrayListOf<String>()

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnView = findViewById<Button>(R.id.btnView)
        val btnExit = findViewById<Button>(R.id.btnExit)

        btnAdd.setOnClickListener {
            showInputDialog()
        }

        btnView.setOnClickListener {
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra("titles", titles.toTypedArray())
            intent.putExtra("artists", artists.toTypedArray())
            intent.putExtra("ratings", ratings.toIntArray())
            intent.putExtra("comments", comments.toTypedArray())
            startActivity(intent)
        }

        btnExit.setOnClickListener {
            finish()
        }
    }

    private fun showInputDialog() {
        val layout = layoutInflater.inflate(R.layout.dialog_input, null)
        val titleInput = layout.findViewById<EditText>(R.id.etTitle)
        val artistInput = layout.findViewById<EditText>(R.id.etArtist)
        val ratingInput = layout.findViewById<EditText>(R.id.etRating)
        val commentInput = layout.findViewById<EditText>(R.id.etComment)

        AlertDialog.Builder(this)
            .setTitle("Add Song to Playlist")
            .setView(layout)
            .setPositiveButton("Add") { _, _ ->
                try {
                    val title = titleInput.text.toString()
                    val artist = artistInput.text.toString()
                    val rating = ratingInput.text.toString().toInt()
                    val comment = commentInput.text.toString()

                    if (rating !in 1..5) throw IllegalArgumentException("Rating must be 1–5")

                    titles.add(title)
                    artists.add(artist)
                    ratings.add(rating)
                    comments.add(comment)

                    Toast.makeText(this, "Song added!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Invalid input: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
