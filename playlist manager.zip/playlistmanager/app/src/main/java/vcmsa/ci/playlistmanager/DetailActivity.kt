package com.example.playlistmanager

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity // ✅ Use the correct AppCompatActivity
import vcmsa.ci.playlistmanager.MainActivity
import vcmsa.ci.playlistmanager.R

class DetailActivity : AppCompatActivity() {

    private lateinit var titles: Array<String>
    private lateinit var artists: Array<String>
    private lateinit var comments: Array<String>
    private lateinit var ratings: IntArray

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail) // ✅ Correct method

        val btnList = findViewById<Button>(R.id.btnList)
        val btnAverage = findViewById<Button>(R.id.btnAverage)
        val btnBack = findViewById<Button>(R.id.btnBack)
        val output = findViewById<TextView>(R.id.tvOutput)

        // ✅ Safely retrieve data from the intent
        titles = intent.getStringArrayExtra("titles") ?: arrayOf()
        artists = intent.getStringArrayExtra("artists") ?: arrayOf()
        ratings = intent.getIntArrayExtra("ratings") ?: intArrayOf()
        comments = intent.getStringArrayExtra("comments") ?: arrayOf()

        btnList.setOnClickListener {
            val builder = StringBuilder()
            for (i in titles.indices) {
                builder.append("🎵 ${titles[i]} - ${artists[i]}\nRating: ${ratings[i]}, Comment: ${comments[i]}\n\n")
            }
            output.text = builder.toString()
        }

        btnAverage.setOnClickListener {
            val avg = if (ratings.isNotEmpty()) ratings.sum().toDouble() / ratings.size else 0.0
            output.text = "Average Rating: %.2f".format(avg)
        }

        btnBack.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
