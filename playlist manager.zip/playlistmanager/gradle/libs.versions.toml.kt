[versions]
kotlin = "1.9.22"
agp = "8.2.2"

[plugins]
android.application = { id = "com.android.application", version.ref = "agp" }
kotlin.android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
kotlin.compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }
